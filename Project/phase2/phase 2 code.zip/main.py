import numpy as np
from itertools import product
from pathlib import Path
from typing import List, Dict, Tuple, Optional


class MarkovDecisionProcess:

    def __init__(self, P, R_low, R_high, Rf, beta, K, n_assets, risk_aversion):
        self.P = np.asarray(P, dtype=float)
        assert self.P.shape == (2, 2)
        self.R = {
            0: np.asarray(R_low, dtype=float),
            1: np.asarray(R_high, dtype=float),
        }
        self.Rf = float(Rf)
        self.beta = float(beta)
        self.a = float(risk_aversion)
        self.n = int(n_assets)
        assert self.R[0].shape == (self.n,) and self.R[1].shape == (self.n,) and self.a > 0
        self.W = [i / K for i in range(K + 1)]
        self._actions = self._build_feasible_actions()

    def states(self) -> List[int]:
        return [0, 1]

    def actions(self, state: int) -> List[np.ndarray]:
        return self._actions

    def transition_prob(self, state: int, action: np.ndarray, next_state: int) -> float:
        return float(self.P[state, next_state])

    def reward(self, state: int, action: np.ndarray, next_state: int) -> float:
        w = np.asarray(action, dtype=float)
        G = float(np.dot(w, self.R[next_state])) + (1.0 - np.sum(w)) * self.Rf
        return float((1.0 - np.exp(-self.a * G)) / self.a)

    def _build_feasible_actions(self) -> List[np.ndarray]:
        acts: List[np.ndarray] = []
        for w_tuple in product(self.W, repeat=self.n):
            w = np.array(w_tuple, dtype=float)
            if np.sum(w) <= 1.0 + 1e-12:
                acts.append(w)
        return acts


def finite_horizon_dp(mdp: MarkovDecisionProcess, T: int) -> Tuple[List[Dict[int, float]], List[Dict[int, np.ndarray]]]:
    states = mdp.states()
    V: List[Dict[int, float]] = [dict() for _ in range(T + 1)]
    pi: List[Dict[int, np.ndarray]] = [dict() for _ in range(T)]
    for z in states:
        V[T][z] = 0.0
    for t in range(T - 1, -1, -1):
        for z in states:
            best_val, best_action = -np.inf, None
            for a in mdp.actions(z):
                exp_val = sum(
                    mdp.transition_prob(z, a, z_next) * (mdp.reward(z, a, z_next) + mdp.beta * V[t + 1][z_next])
                    for z_next in states
                )
                if exp_val > best_val:
                    best_val, best_action = exp_val, a
            V[t][z] = float(best_val)
            pi[t][z] = np.array(best_action, dtype=float)
    return V, pi


if __name__ == "__main__":
    from estimate_regime_params import RegimeParamsEstimator, TICKERS

    data_dir = Path(__file__).resolve().parent / "data"
    estimator = RegimeParamsEstimator(data_dir=data_dir, rf_gross=1.0)
    P, R_low, R_high, Rf = estimator.build_params(verbose=False)

    mdp = MarkovDecisionProcess(P=P, R_low=R_low, R_high=R_high, Rf=Rf, beta=0.99, K=10, n_assets=len(TICKERS), risk_aversion=1.0)
    V, pi = finite_horizon_dp(mdp, T=10)

    T = 10
    print("V (value by t and regime):")
    for t in range(T + 1):
        print("  t={}: z=0 -> {}, z=1 -> {}".format(t, V[t][0], V[t][1]))
    print("pi (optimal weights [AAPL,TSLA,MSFT] by t and regime):")
    for t in range(T):
        print("  t={}: z=0 -> {}, z=1 -> {}".format(t, pi[t][0], pi[t][1]))
